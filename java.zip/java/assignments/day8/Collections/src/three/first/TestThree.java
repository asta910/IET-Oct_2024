package three.first;

import java.util.Scanner;

//rite a menu driven program to maintain student information. Modify Student class
//created in previous assignment. Add a member gpa in student class, add a function in
//student class to return GPA of a student
// calculateGPA()
// gpa=(1/3)*m1+(1/2)*m2+(1/4)*m3
//Create an array to store Multiple students.
//1. Display All Student
//2. Search by id
//3. Search by name
//4. calculate GPA of a student
//5. Exit
public class TestThree {
    public static void main(String[] args) {
        int output = 0;
        System.out.println("Welcome..");
        Scanner sc = new Scanner(System.in);
        Service service = new Service();

        while (output != 5){
            System.out.println("1. Display All Student \n2. Search by id \n3. Search by name  \n4. calculate GPA of a student \n5. Exit");
            System.out.print("Enter output : ");
            output = sc.nextInt();

            switch (output){
                case  1 :
                    service.showAll();
                    break;
                case 2:
                    System.out.println("Enter id of student you want to search : ");
                    int id = sc.nextInt();
                    service.searchById(id);
                    break;
                case 3:
                    System.out.println("Enter name of student you want to search : ");
                    sc.nextLine();
                    String name = sc.next();
                    service.searchByName(name);
                    break;
                case 4:
                    service.getCGP();
                    break;
                default:
                    System.out.println("Wrong choice...");
                    break;
            }
        }
        System.out.println("Thank you..");

    }
}
