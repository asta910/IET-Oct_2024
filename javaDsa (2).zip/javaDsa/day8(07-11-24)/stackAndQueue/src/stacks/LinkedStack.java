package stacks;

public class LinkedStack <T> {
    class Node {
        T val;
        Node next;
        public Node(T v){
            this.val=v;
            next = null;
        }
    }

    Node top = null;

    public void push(T v){
        Node newNode = new Node(v);
        if (top == null){
            top=newNode;
        }else{
            newNode.next = top;
            top=newNode;
        }
    }

    public T pop(){
        T ans = null;
        if (isEmpty()){

        }else{
             Node p = top;
             top=p.next;
             p.next=null;
             return p.val;
        }
        return ans;
    }

    public boolean isEmpty(){
        return top == null;
    }

    public String toString(){
        Node temp = top;
        StringBuilder str = new StringBuilder(".");
        while (temp.next != null){
            T val = temp.val;
            if (temp != top){
                str.insert(0, ", ");
            }
            str.insert(0,val);
            temp=temp.next;
        }

        str.insert(0,", ");
        str.insert(0,temp.val);
        return str.toString();
    }
}