package com.demo.services;

public interface AdminService {
    boolean setInterest(char ch,int i);
}
