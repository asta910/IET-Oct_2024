package demo.bean.test;

import demo.bean.exception.EmployeeException;
import demo.bean.services.EmployeeService;
import demo.bean.services.EmployeeServiceImpl;

import java.util.Scanner;

public class EmployeeTest {
    public static void main(String[] args){
        System.out.println("Welcome to NEDVED Factory....");
        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        EmployeeService employeeService = new EmployeeServiceImpl();
        employeeService.readDatFromFile("employee.dat");
        while(choice != 7){
            System.out.println("1. Add new Employee \n2. Delete Employee\n3. Update employee");
            System.out.println("4. Display all \n5. Sort by salary \n6. Sort by id \n7. Save & exit \nchoice : ");
            choice = scanner.nextInt();

            switch (choice){
                case 1:
                        employeeService.addEmployee();
                    break;
                case 2:
                    try {
                        System.out.println("enter id");
                        int id=scanner.nextInt();
                        employeeService.DeleteEmployee(id);
                    }catch(EmployeeException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    System.out.println("Enter id of account you want to updated : ");
                    int id = scanner.nextInt();
                    employeeService.updateEmployee(id);
                    break;
                case 4:
                    employeeService.displayEmployee();
                    break;
                case 5:
                    employeeService.sortBySalary();
                    break;
                case 6:
                    employeeService.sortByID();
                    break;
                default:
                    System.out.println("Only 8 options available choose properly");
                    break;
            }

        }
        try {
            employeeService.saveInFile("employee.dat");
            System.out.println("File saved successfully..");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
