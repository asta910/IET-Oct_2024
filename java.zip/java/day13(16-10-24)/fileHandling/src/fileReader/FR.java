package fileReader;

import demo.bean.bean.Employee;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FR {
    public static void main(String[] args) throws IOException {
        List<Employee> list = new ArrayList<>();
        list.add(new Employee(3, "Omen", 25000, 2000));
        list.add(new Employee(4, "Ronaldo", 40000, 4000));
        list.add(new Employee(2, "asta", 50000, 4000));
        list.add(new Employee(1, "Ancient One", 20000, 1000));


        try (ObjectOutputStream objectInputStream = new ObjectOutputStream(new FileOutputStream("employee.dat"))) {
            for (Employee e : list){
                objectInputStream.writeObject(e);
            }

        }
    }
}
