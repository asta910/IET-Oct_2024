import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        try (FileInputStream fis = new FileInputStream("test1.txt");
            FileOutputStream fos = new FileOutputStream("testCpy.txt");)
        {
            int input = fis.read();
            while(input!=-1){
                fos.write(input);
                input = fis.read();
            }
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
