package threadsThread;

import beans.MyClass;

public class Providor2 extends Thread {
    private MyClass object;
    private int n;
    public Providor2(MyClass myClass,int n){
        this.object = myClass;
        this.n=n;
    }
    public void run(){
        object.printTable(n);
    }
}
