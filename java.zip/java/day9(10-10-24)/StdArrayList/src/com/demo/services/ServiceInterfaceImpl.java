package com.demo.services;

import com.demo.beans.Graduation;
import com.demo.beans.Masters;
import com.demo.dao.PersonInterface;
import com.demo.dao.PersonInterfaceImpl;
import com.demo.beans.Person;

import java.util.ArrayList;
import java.util.Scanner;


public class ServiceInterfaceImpl implements ServiceInterface{
    PersonInterface personInterface = new PersonInterfaceImpl();
    Scanner sc = new Scanner(System.in);

    //1. create student
    public boolean createStudent(){
        System.out.println("Enter which type of student you want to add : ");
        System.out.println("1. Graduation \n2. Masters \n3. get back");
        System.out.print("Enter you choice : ");
        int choice = sc.nextInt();
        System.out.print("Enter id : ");
        int gid = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter student name : ");
        String gName = sc.nextLine();
        System.out.println("Enter student address : ");
        String gAddress = sc.nextLine();
        System.out.print("Enter marks for subject 1 : ");
        int m1 = sc.nextInt();
        System.out.print("Enter marks for subject 2 : ");
        int m2 = sc.nextInt();
        System.out.print("Enter marks for subject 3 : ");
        int m3 = sc.nextInt();
        int[] m = {m1,m2,m3};
        sc.nextLine();

        if(choice == 1){
            System.out.print("Enter special subject marks : ");
            int gssub = sc.nextInt();
            boolean res = personInterface.createGraduationStudent(gid,gName,gAddress,m,gssub);
            return res;
        }
        else if(choice == 2){
            System.out.print("Enter thesis subject Name : ");
            String mtsub = sc.nextLine();
            System.out.print("Enter thesis subject marks : ");
            int gssub = sc.nextInt();
            boolean res = personInterface.createMastersStudent(gid,gName,gAddress,m,mtsub,gssub);
            return res;
        }
        return false;
    }


    //2 delete student
    public boolean deleteStudent(){
        System.out.print("Enter id of student you want to delete : ");
        int id = sc.nextInt();
        boolean del = personInterface.deleteStudent(id);
        return del;
    }


    //3 modify marks
    public boolean modifyMarks(){
        System.out.print("Enter id of student who's marks you want to modify : ");
        int gid = sc.nextInt();
        System.out.print("Enter updated marks for subject 1 : ");
        int m1 = sc.nextInt();
        System.out.print("Enter updated marks for subject 2 : ");
        int m2 = sc.nextInt();
        System.out.print("Enter updated marks for subject 3 : ");
        int m3 = sc.nextInt();
        int[] m = {m1,m2,m3};

        boolean mod = personInterface.modifyMarks(gid,m);
        return mod;
    }


    //4 search by id
    public void searchById(){
        System.out.print("Enter id of student who you want to see : ");
        int gid = sc.nextInt();
        personInterface.searchById(gid);
    }



    public void displayByMarks(){
        ArrayList<Person> ans = personInterface.displayByMarks();
        for (Person p : ans){
            System.out.println(p);
        }
    }

    public void sortById(){
        personInterface.sortById();
    }

    public void sortByMarks(){
        personInterface.sortByMarks();
    }

    public void showAll(){
        personInterface.showAll();
    }

    public void sortByName(){
        personInterface.sortByName();
    }

    public boolean addFaculty(){
        boolean res = personInterface.addFaculty();
        if (res){
            System.out.println("Faculty added succesfully..");
        }
        return res;
    }

}
