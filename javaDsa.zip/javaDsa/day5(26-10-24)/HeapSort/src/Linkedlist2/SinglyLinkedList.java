package Linkedlist2;

public class SinglyLinkedList {
    Node head ;

    class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
        public void SinglyLinkedList(){
            head = null;
        }


        public void addNode(int val) {
            Node newnode = new Node(val);
            if (head == null) {
                head = newnode;
            }
            else{
                Node temp = head;
                while(temp.next !=null){
                    temp =temp.next;
                }
                temp.next = newnode;
            }
        }
        public void displayData(){
            if(head == null){
                System.out.println("List is emptyy");
            }
            else{
                Node temp = head;
                while(temp!=null){
                    System.out.println(temp.data);
                    temp = temp.next;
                }
            }
        }
        public void addByPosition(int val,int pos){
        if(head ==null && pos>1){
            System.out.println("List is empty");
        }
        else{
            Node newnode = new Node(val);
            if(pos==1){
                newnode.next = head;
                head =newnode;
            }
            else{
                Node temp = head;
                for (int i = 0;temp!=null && i < pos-2; i++) {
                    temp = temp.next;
                }
                if(temp!=null){
                    newnode.next = temp.next;
                    temp.next = newnode;
                }
                else{
                    System.out.println("No position found in a linked list");
                }
            }
        }
        }
        public void deleteByValue(int val){
        Node temp=head;
            Node prev = null;
        if(head == null){
            System.out.println("list is empty");
        }
        else{
            if(head.data == val){
                head = temp.next;
                temp.next = null;
                temp=null;
            }else{
                while(temp!=null && temp.data!=val){
                    prev = temp;
                    temp = temp.next;
                }
                if(temp!=null){
                    prev.next = temp.next;
                    temp.next = null;
                    temp = null;
                }else {
                    System.out.println("Data not found");
                }
            }
        }
    }
    public void deletByPosition(int pos){
        Node temp = head;
        Node prev = null;
        if(head ==null){
            System.out.println("List is empty");
        }
        else{
            if(pos==1){
                head = temp.next;
                temp.next = null;
                temp = null;
            }
            else{
                for(int i=0;temp!=null && i<=pos-1;i++){
                    prev = temp;
                    temp = temp.next;
                }
                if(temp!=null){
                    prev.next = temp.next;
                    temp.next = null;
                    temp = null;
                }
                else {
                    System.out.println("Data not found");
                }
            }
        }
    }

}