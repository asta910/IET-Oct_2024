package producerConsumer;

import java.util.List;

public class Product {
    private boolean status;
    List<Integer> products;
    public Product(){
        this.status=false;
    }
    public void put(int i){
        while (status){
            try{
                wait();
            }catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
            products.add(i);
            System.out.println("Added element from producer : " + i);
            status=true;
            notify();
        }
    }
    public int get(){
        int value= 0;
        while (!status){
            try{
                    wait();
            }catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
            int ans = products.get(products.size());
            System.out.println("Found element from producer : " + ans);
            status=false;
            notify();
            value=ans;
        }
        return value;
    }
}
