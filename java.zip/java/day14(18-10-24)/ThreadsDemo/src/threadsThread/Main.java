package threadsThread;

import beans.MyClass;

public class Main {
    public static void main(String[] args) {
        MyClass myClass = new MyClass();

        Providor provider1 = new Providor(myClass, 5);
        Providor provider2 = new Providor(myClass, 10);

        provider1.start();
        provider2.start();

        try {
            provider1.join(); // Wait for provider1 to finish
            provider2.join(); // Wait for provider2 to finish
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}