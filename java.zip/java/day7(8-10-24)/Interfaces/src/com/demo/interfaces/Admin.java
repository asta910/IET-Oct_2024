package com.demo.interfaces;

public class Admin {
}
