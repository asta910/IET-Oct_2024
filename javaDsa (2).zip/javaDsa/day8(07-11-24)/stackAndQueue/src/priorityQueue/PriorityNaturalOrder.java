package priorityQueue;

import java.util.Arrays;

public class PriorityNaturalOrder{
    private int[] arr;
    private int top;

    public PriorityNaturalOrder(int size){
        arr= new int[size];
        top = -1;
    }

    public boolean isFull(){
        return top + 1 == arr.length;
    }

    public boolean isEmpty(){
        return top == -1;
    }

    public void add(int v){
        if (isFull()){
            expandSize();
        }
        arr[++top] = v;
        Arrays.sort(arr,0,top+1);
    }

    public int poll(){
        int ans = Integer.MIN_VALUE;
        if (isEmpty()){
            System.out.println("Queue is empty");
        }else{
            ans = arr[0];
            for (int i =0; i < top; i++){
                arr[i] = arr[i+1];
            }
            top--;
        }
        return ans;
    }

    public void expandSize(){
        int l = arr.length;
        int newL = l << 1;
        int[] newArr =  new int[newL];
        System.arraycopy(arr,0,newArr,0,l);
        Arrays.fill(newArr,Integer.MIN_VALUE,top,newL);
        arr=newArr;
    }
}
