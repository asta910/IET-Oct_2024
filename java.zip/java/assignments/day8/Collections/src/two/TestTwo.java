package two;

import java.util.Scanner;

//rite a program to maintain student information. For each student store studid, name, m1,
//m2 and m3 (marks of 3 subjects ). Accept information for 2 students and display it as
//follows.
public class TestTwo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter details od students");
        for (int i = 0; i < 3; i++) {
            System.out.println("Enter student id : ");
            int studid = sc.nextInt();
            System.out.println("Enter student name : ");
            String name = sc.next();
            System.out.println("Enter student m1 : ");
            int m1 = sc.nextInt();
            System.out.println("Enter student m2 : ");
            int m2 = sc.nextInt();
            System.out.println("Enter student m3 : ");
            int m3 = sc.nextInt();
            System.out.println("Student details are : "+studid+" "+" "+name+" "+m1+" "+m2+" "+m3);
//            Student Details:
//            ____________
//            Student Id
//            Name: Divya
//            M1 : 78
//            M2: 86
//            M3: 89
            System.out.println("Student Details: ");
            System.out.println("_______________ ");
            System.out.println("Student ID: "+studid);
            System.out.println("Name: "+name);
            System.out.println("M1: "+m1);
            System.out.println("M2: "+m2);
            System.out.println("M3: "+m3);

        }
    }
}
