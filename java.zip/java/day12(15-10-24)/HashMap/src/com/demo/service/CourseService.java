package com.demo.service;

public interface CourseService {
    boolean addCourse(String nm,double dd,int cap, int dur,String[] arf,String[] arm);
    void displayAll();
    boolean deleteCourse(String nm, int id);
    boolean searchByName(String courseName);
    boolean updateCourse(char ch,int i,String c);
    boolean updateCourseString(char ch,String[] arr,String s);

    boolean displayBasedOnDur(int d);
    boolean nameSort();
    boolean durationSort();

    boolean feesSort();

    boolean facultyNames();

    boolean moduleNames();
}
