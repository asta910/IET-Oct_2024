package demo.bean.services;

import demo.bean.bean.Employee;
import demo.bean.dao.EmployeeDao;
import demo.bean.dao.EmployeeDaoImpl;

import java.util.List;
import java.util.Scanner;

public class EmployeeServiceImpl implements EmployeeService{
    Scanner scanner = new Scanner(System.in);
    EmployeeDao employeeDao = new EmployeeDaoImpl();


    public void addEmployee() {
        System.out.print("Enter id of employee : ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter employee name : ");
        String name = scanner.nextLine();
        System.out.print("Enter employee salary : ");
        int sal = scanner.nextInt();
        System.out.print("Enter employee bonus : ");
        int bonus = scanner.nextInt();
        Employee employee = new Employee(id,name,sal,bonus);
        employeeDao.saveEmployeeToList(employee);
    }

    public void readDatFromFile(String fileName){
        employeeDao.readDatFromFile(fileName);
    }

    public void sortBySalary() {
        List<Employee> ans = employeeDao.sortBySalary();
        displayEmployee(ans);
    }

    @Override
    public void sortByID() {
        List<Employee> ans = employeeDao.sortByID();
        displayEmployee(ans);
    }

    public void DeleteEmployee(int id) {
        Employee employee = new Employee(id);
        employeeDao.remove(employee);
    }

    public void updateEmployee(int id) {
        Employee employee = employeeDao.findEmployee(id);
        System.out.println("What you wanna update ? \n1. Set bonus \n2. Set salary \n Enter salary");
        int choice = scanner.nextInt();
        if (choice == 1) {
            System.out.println("Please enter new bonus to update it:  ");
            int bonus= scanner.nextInt();
            employeeDao.modifyEmployee(employee,'b',bonus);
        }
        else if (choice == 2) {
            System.out.println("Please enter new salary to update it:  ");
            int salary= scanner.nextInt();
            employeeDao.modifyEmployee(employee,'s',salary);
        }else{
            System.out.println("You entered invalid choice");
        }

    }

    public void displayEmployee() {
        List<Employee> ans = employeeDao.showAll();
        for (Employee e : ans){
            System.out.println(e);
        }
    }
    private void displayEmployee(List<Employee> ans) {
        for (Employee e : ans){
            System.out.println(e);
        }
    }
    public void saveInFile(String path){
        employeeDao.saveInFile(path);
    }

}
