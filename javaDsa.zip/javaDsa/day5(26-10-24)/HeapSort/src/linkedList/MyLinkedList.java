package linkedList;

public class MyLinkedList {

    class Node{
        int value;
        Node next;

        public Node(int v){
            this.value = v;
            this.next=null;
        }
    }
    Node head;

    //add
    public void add(int v){
        Node node = head;
        Node newNode = new Node(v);
        if (head == null){
            head = newNode;
        }else{
            while (node.next != null){
                node=node.next;
            }
            node.next=newNode;
        }
    }

    //display
    public void display(){
        Node node = head;
        while (node != null){
            System.out.print(node.value + " -->  ");
            node=node.next;
        }
    }

    public void addAtIndex(int v,int index){
        Node newNode = new Node(v);
        Node node = head;
        Node prev = null;

        if (head == null){
            head = newNode;
            System.out.println("No value found in Linked List.. so added first ");
        }
        else if(index == 1) {
          Node actual = head;
          newNode.next=actual;
          head = newNode;
        }
        else{
            while (node.next != null && index != 1) {
                prev = node;
                node = node.next;
                index--;
            }
            if (node.next != null){
                prev.next = newNode;
                newNode.next = node;
            }else{
                node.next=newNode;
            }
        }

    }
}
