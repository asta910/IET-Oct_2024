package DaCode;

import java.util.Arrays;

public class mergeSort {
    public static void main(String[] args) {
        int[] a={1,4,3,0,5,9,8,10,7,1,3,3,2,2};
        int[] ans = sort(a);
        System.out.println(Arrays.toString(ans));

    }
    public static int[] sort(int[] a){
        if (a.length==0) return a;
        int mid = a.length/2;

        int[] left = Arrays.copyOfRange(a,0,mid);
        int[] right = Arrays.copyOfRange(a,mid,a.length);
        left = sort(left);
        right = sort(right);
        return mrege(left,right);

    }

    private static int[] mrege(int[] a, int[] b) {
        int[] c = new int[a.length+b.length];
        int i=0,j=0,k=0;
        while(i<a.length && j<b.length){
            if(a[i]<b[j]){
                c[k]=a[i];
                i++;
                k++;
            }
            if(a[i]>b[j]){
                c[k]=b[j];
                j++;
                k++;
            }
            while(i<a.length){
                c[k]=a[i];
                k++;
                i++;
            }
            while(j<b.length){
                c[k]=b[j];
                k++;
                j++;
            }

        }

        return c;
    }
}
