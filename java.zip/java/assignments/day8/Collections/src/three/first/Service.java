package three.first;

import java.util.ArrayList;
import java.util.List;

public class Service {
    static List<Student2> list;
    static {
        list = new ArrayList<>();
        list.add(new Student2(100,"Daku",100,90,80));
        list.add(new Student2(2,"Asta",100,100,100));
    }
    public void showAll(){
        for (Student2 s : list){
            System.out.println(s);
        }
    }
    public void searchById(int id){
        Student2 student2 = new Student2(id);
        int postion = list.indexOf(student2);
        if (postion != -1){
            System.out.println(list.get(postion));
        }else {
            System.out.println("Not found..");
        }
    }
    public void searchByName(String name){
        int postion = getPosition(name);
        if (postion != -1){
            System.out.println(list.get(postion));
        }else {
            System.out.println("Not found..");
        }
    }
    public void getCGP(){
        for (Student2 s : list){
            int m1=s.getM1();
            int m2=s.getM2();
            int m3=s.getM3();
            double gpas=(double) (0.33)*m1+(0.5)*m2+(0.25)*m3;
            System.out.println(s + " CGPA IS : " + gpas);
        }
    }
    private int getPosition(String s){
        int count = 0;
        for (Student2 obj : list){
            if (obj.getName().equals(s)){
                return count;
            }
            count++;
        }
        return -1;
    }
}
