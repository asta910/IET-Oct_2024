package BinarySearchQues;

public class BinarySearchImpl implements BinarySearch{
    public int[] searchLowerAndUpperBound(int[] a) {
        return new int[0];
    }

    @Override
    public int searchLowerInsertPPosition(int[] a) {
        return 0;
    }

    @Override
    public int[] firstAndLastOccurance(int[] a) {
        return new int[0];
    }

    @Override
    public int searchInSortedRotatedArray(int[] a) {
        return 0;
    }

    @Override
    public int minElementInRotatedArray(int[] a) {
        return 0;
    }

    @Override
    public int peakElementInMountedArray(int[] a) {
        return 0;
    }
// 1. SLower and Upper Bound
// 2. Search insert position
// 3. Sqrt(x)
// 4. First and Last occurrence of a number
// 5. Search in sorted rotated array
// 6. Min element in sorted rotated array
//Find peak element in a mountain array




}
