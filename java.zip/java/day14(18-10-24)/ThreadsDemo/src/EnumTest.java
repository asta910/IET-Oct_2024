import enumPackage.Coffee;

public class EnumTest {
    public static void main(String[] args) {
        Coffee coffee = Coffee.SMALL;
//        There is no tomorrow ? is there ? when was last time you saw tomorrow ?
    }
}
