package sorting;

import java.util.Arrays;

public class mergeSort {
    public static void main(String[] args) {
        int[] a={1,4,3,0,5,9,8,10,7,1,3,3,2,2};
        System.out.println(Arrays.toString(a));
        int[] ans = sort(a);

        System.out.println(Arrays.toString(ans));
    }
    public static int[] sort(int[] a){
        if (a.length == 1) return a;
        int mid = a.length/2;
        int[] left = Arrays.copyOfRange(a,0,mid);
        int[] right = Arrays.copyOfRange(a,mid,a.length);

        left = sort(left);
        right = sort(right);

        return mrege(left,right);
    }

    private static int[] mrege(int[] l, int[] r) {
        int[] ans = new int[l.length + r.length];
        int i=0,k=0,j=0;

        while (i < l.length && j < r.length){
            if (l[i] < r[j]) ans[k++] = l[i++];
            else ans[k++] = r[j++];
        }
        while (i < l.length) ans[k++]=l[i++];
        while (j < r.length) ans[k++]=r[j++];
        return ans;
    }
}
