package enumPackage;

public enum Coffee {
    SMALL(230,340),MEDIUM(450,600),BIG(650,1200);
    private int size;
    private int price;

    private Coffee(int size,int price){
        System.out.println("Constuctor called for - " );
        this.size = size;
        this.price = price;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
