package producerConsumer;

import java.util.ArrayList;
import java.util.List;

public class Corrected {
    private boolean status; // true if there's a product available
    private final List<Integer> products; // List to hold products

    public Corrected() {
        this.status = false;
        this.products = new ArrayList<>(); // Initialize the list
    }

    public synchronized void put(int i) {
        while (status) { // If there's already a product, wait
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); // Restore interrupted status
                System.out.println(e.getMessage());
            }
        }
        products.add(i); // Add product to the list
        System.out.println("Added element from producer: " + i);
        status = true; // Update status to indicate a product is available
        notify(); // Notify consumers that a product is available
    }

    public synchronized int get() {
        while (!status) { // If no product is available, wait
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); // Restore interrupted status
                System.out.println(e.getMessage());
            }
        }
        int ans = products.remove(products.size() - 1); // Remove and get the last product
        System.out.println("Found element from consumer: " + ans);
        if (products.isEmpty()) { // If no products left, update status
            status = false;
        }
        notify(); // Notify producers that space is available
        return ans;
    }
}