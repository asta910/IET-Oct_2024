package linkedList;

public class TestLinkedList {
    public static void main(String[] args) {
        MyLinkedList list = new MyLinkedList();
        list.add(30);
        list.add(10);
        list.add(20);
        for (int i =5; i <= 8; i++){
            list.add(i*10);
        }
        list.addAtIndex(106,6);
        System.out.println();
        System.out.println();

        list.display();

        System.out.println();
        System.out.println();
    }
}
