package treeSort;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] a = {10,4,6,8,9,2,5};
        SortingTreeMaxHeap.heapSort(a);
        System.out.println(Arrays.toString(a));
    }
}
