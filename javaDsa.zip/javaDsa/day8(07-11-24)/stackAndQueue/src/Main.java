import stacks.LinkedStack;

import java.util.LinkedList;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {
        Queue<Integer> q = new LinkedList<>();

        LinkedStack<String> stack = new LinkedStack<>();
        stack.push("Daku");
        stack.push("Mangal");
        stack.push("Singh");
        stack.push("Kirmada");
        stack.push("Daku");
        stack.push("Mangal");
        stack.push("Singh");
        stack.push("Kirmada");
        System.out.println(stack);
        for (int i =0; i < 10; i++){
            System.out.println(stack.pop());
        }

    }
}