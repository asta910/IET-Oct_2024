package com.demo.dao;

import com.demo.beans.Person;
import java.util.ArrayList;

public interface PersonInterface {
    boolean createGraduationStudent(int gid,String gName,String gAddress,int[] m,int gssub);
    boolean createMastersStudent(int gid,String gName,String gAddress,int[] m,String mtsub,int gssub);
    boolean deleteStudent(int id);
    boolean modifyMarks(int id,int[] m);


    void searchById(int gid);
    boolean addFaculty();
    ArrayList<Person> displayByMarks();
    void sortById();
    void sortByMarks();
    void showAll();
    void sortByName();
}
