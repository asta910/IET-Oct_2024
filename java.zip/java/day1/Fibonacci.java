import java.util.Scanner;
public class Fibonacci {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number until where you want to print series");
        int n = sc.nextInt();
        int a = 0;
        int b = 1;
        System.out.print(a + " ");
        System.out.print(b + " ");
        int sum=0;
        for(int i=2;i<n;i++)
        {
            sum=a;
            a=b;
            b=sum+a;
            System.out.print(b + " ");
        }
        
        sc.close();
    }
    
}
