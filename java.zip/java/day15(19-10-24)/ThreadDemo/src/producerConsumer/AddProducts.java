package producerConsumer;

public class AddProducts extends Thread {
    Product product;

    public AddProducts(Product product){
        this.product = product;
    }

    public void run(){
        for (int i =1; i <= 10; i++){
            product.put(i);
        }
    }
}
