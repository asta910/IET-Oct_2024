package three.second;

import three.first.Service;

import java.util.Scanner;

//And do the following.
//        1. Display All Friend
//2. Search by id
//3. Search by name
//4. Display all friend with a particular hobby
//5. Exit
public class TestFriends {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter details of students");
        int choice ;
        FriendService service = new FriendService();
        do {
            System.out.println("1. Display All Friends \n2. Search by id \n3. Search by name \n4. Display all friend with particular hobby \n.Exit ");
            System.out.print("Enter the choice : ");
            choice = sc.nextInt();

            switch(choice){
                case 1:
                    service.displayAll();
                    break;
                case 2:
                    int id = sc.nextInt();
                    service.searchById(id);
                    break;
                case 3:
                    String name = sc.next();
                    service.searchByName(name);
                    break;
                case 4:
                    service.displayByHobbie();
                    break;
                case 5:
                    System.out.println("Thank you");
                    break;
                default:
                    System.out.println("You entered wrong choice");
                    break;
            }
        }while(choice!=6);
    }
}
