package sorting;

import java.util.Arrays;

public class counting {
    public static void main(String[] args) {
        int[] a={1,4,3,0,5,9,8,10,7,1,3,3,2,2};
        System.out.println(Arrays.toString(a));
        int max = Integer.MIN_VALUE;
        for (int i : a) max = Math.max(i,max);

        int[] count = new int[max+1];

        for (int i = 0; i < a.length; i++){
            count[a[i]]++;
        }

        System.out.println(Arrays.toString(count));

        for (int i = 1; i < count.length ; i++) {
            count[i] =count[i] + count[i-1];
        }

        System.out.println(Arrays.toString(count));

        int[] ans = new int[a.length];

        for (int i = 0; i < a.length; i++) {
            ans[ count[a[i]] -1] = a[i];
            count[a[i]]--;
        }
        System.out.println("ans : " +Arrays.toString(ans));
    }
}
