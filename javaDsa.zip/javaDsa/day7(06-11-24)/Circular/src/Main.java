public class Main {
    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();

        for (int i =11; i >= 1; i--){
            list.addNode(i);
        }
        list.addNode(11);
        list.print();
        list.size();
        System.out.println(list.findOccuranceOf(11));
        list.size();
    }
}