package producerConsumer;

import java.util.ArrayList;
import java.util.List;

public class GetProducts extends Thread{
    Product product;
    List<Integer> ans = new ArrayList<>();
    public GetProducts(Product product){
        this.product = product;
    }

    public void run(){
        for (int i =1; i <= 10; i++){
            int value = this.product.get();
            ans.add(value);
        }
    }

    public List<Integer> getAns(){
        return ans;
    }

}
