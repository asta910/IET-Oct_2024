import java.util.Scanner;

public class NumMod {
    public static void main(String[] args) {
        System.out.println("Enter 10 Numbers ");
        Scanner sc = new Scanner(System.in);
        int sum = 0;

        for(int i =0; i < 10; i++){
            int num = sc.nextInt();
            if(num % 3 ==0 || num % 5 == 0 || num % 11 == 0){
                sum += num;
            }
        }
        System.out.println("Sum is : " + sum );
    }
}
