package sorting.me;

import java.util.Arrays;

public class CountingSort {
    public static void main(String[] args) {
        int[] array = {70, 40, 50, 90, 100, 10, 30, 20, 10, 30};
        System.out.println(Arrays.toString(array));
        insertion(array);
        System.out.println(Arrays.toString(array));
    }

    private static void insertion(int[] a){
        for (int i = 1; i < a.length ; i++) {
            int value = a[i];
            int j = i - 1;
            while (j >= 0 && value < a[j]){
                a[j+1] = a[j];
                j--;
            }
            a[j+1] = value;
        }
    }
}

