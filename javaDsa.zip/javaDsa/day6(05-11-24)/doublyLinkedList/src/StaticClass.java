public  class StaticClass {
    public static class newClz{

    }
}
