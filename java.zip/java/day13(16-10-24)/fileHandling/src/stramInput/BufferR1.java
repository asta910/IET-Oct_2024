package stramInput;

import java.io.*;


public class BufferR1 {
    public static void main(String[] args) throws IOException {
        try(BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream("one.txt"));
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream("two.txt"))){
            int i = bufferedInputStream.read();
            while (i != -1){
                bufferedOutputStream.write(i);
                i=bufferedInputStream.read();
                System.out.println((char) i);
            }

        }catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
}
