package com.demo.interfaces;

public interface AdminInterface {
    void showAllAccounts();
}
