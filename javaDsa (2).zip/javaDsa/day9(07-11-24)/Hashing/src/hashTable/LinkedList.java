package hashTable;

public class LinkedList {
    public int[] giveKeys() {
        int[] ans = new int[getSize()];
        if (head==null) return ans;
        int i = 0;
        Node temp = head;
        while (temp != null){
            ans[i++] = temp.val;
            temp=temp.next;
        }
        return ans;
    }

    public String[] giveValues() {
        String[] ans = new String[getSize()];
        if (head==null) return ans;
        int i = 0;
        Node temp = head;
        while (temp != null){
            ans[i++] = temp.name;
            temp=temp.next;
        }
        return ans;
    }

    class Node{
        int val;
        String name;
        Node next;

        private Node(int v,String s){
            this.val=v;
            this.name = s;
            this.next=null;
        }
    }
    Node head = null;

    public void add(int v,String s){
        Node newNode = new Node(v,s);
        if (head == null){
            head = newNode;
        }else{
            Node temp = head;
            while (temp.next != null){
                temp=temp.next;
            }
            temp.next=newNode;
        }
    }

    public boolean remove(int i){
        if (head == null) return false;
        else{
            if (head.val == i){
                Node del = head;
                head = head.next;
                del.next=null;
            }else{
                Node prev = null;
                Node temp = head;
                while (temp != null && temp.val != i){
                    prev = temp;
                    temp=temp.next;
                }
                if (temp == null){
                    return false;
                }else{
                    if(temp.next != null){
                        Node n1 = temp.next;
                        prev.next=n1;
                        temp.next=null;
                    }else{
                        prev.next=null;
                        temp.next=null;
                    }
                }
            }
        }
        return true;
    }
    public String findByKey(int k){
        if (head == null) return null;
        String ans = "";
        if (head.val == k){
            ans=head.name;
        }else{
            Node temp = head;
            while (temp != null && temp.val != k){
                temp=temp.next;
            }if (temp!= null){
                ans=temp.name;
            }
        }
        return ans;
    }

    public String getList() {
        StringBuilder str = new StringBuilder();
        if (head == null) {
            return null;
        } else {
            Node temp = head;
            while (temp != null) {
                str.append(temp.val).append(" : ").append(temp.name).append(", ");
                temp = temp.next;
            }
            if (str.length() > 0) {
                str.setLength(str.length() - 2);
            }
        }
        return str.toString();
    }

    public int getSize(){
        int count = 0;
        if (head == null) return count;
        Node temp = head;
        while (temp!= null){
            temp=temp.next;
            count++;
        }
        return count;
    }

    public void clearList(){
        if (head==null) return;
        Node t = head;
        while (t != null){
            Node current = t;
            t=t.next;
            current.next=null;
            current=null;
        }
        head=null;
    }
}
