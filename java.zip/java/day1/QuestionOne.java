
import java.util.*;

public class QuestionOne {
    public static void main(String[] args) {
        int[] arr = { 40, 10, 20, 30,12,23,43 };
        int[] ans = arrayRankTransform(arr);

        System.out.println(Arrays.toString(ans));
    }

    static int[] arrayRankTransform(int[] arr) {
        int n = arr.length;
        int[] ans = new int[n];
        ArrayList<int[]> list = new ArrayList<>(); 


        for (int i = 0; i < n; i++) {
            list.add(new int[] {arr[i], i });
        }

        Collections.sort(list,Comparator.comparingInt(a -> a[0]));
        
        int rank = 0;
        for (int i = 0; i < n ; i++) {
            if( i == 0 || list.get(i)[0] != list.get(i - 1)[0]){
                rank++;
            }
            ans[list.get(i)[1]] = rank;
        }
        return ans;
    }

}
