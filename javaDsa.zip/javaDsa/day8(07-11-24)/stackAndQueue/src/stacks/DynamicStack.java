package stacks;

public class DynamicStack {
        private int top;
        private int[] arr;
        public DynamicStack(){
            top = -1;
            arr=new int[5];
        }

        public boolean isEmpty(){
            return top == -1;
        }
        public boolean isFull(){
            return top + 1 == arr.length;
        }
        public int pop() throws StackOverflowError{
            int ans = Integer.MIN_VALUE;

            if (isEmpty()){
                System.out.println("Stack is empty");
            } else {
                try {
                    if (isEmpty()){
                        throw new StackOverflowError();
                    }
                    ans = arr[top--];
                }catch (StackOverflowError e){
                    System.out.println(e.getStackTrace());
                }
            }
            if ((top * 2) - 4< arr.length){
                reduceSize();
            }
            System.out.println("Size is " + arr.length + " Saved " + (arr.length - top) );
            return ans;
        }

        public void push(int v){
            if (isFull()) {
                expandSize();
            }
                arr[++top]=v;
            System.out.println("Size is " + arr.length + " Saved " + (arr.length - top) );
        }

        public void expandSize(){
            int l = arr.length;
            int newL = l << 1;
            int[] newArr = new int[newL];
            System.arraycopy(arr,0,newArr,0,l);
            arr=newArr;
        }

        public void reduceSize(){
            int l = arr.length;
            int newL = l >> 1;
            int[] newArr = new int[newL+4];
            System.arraycopy(arr,0,newArr,0,newL);
            arr=newArr;
        }

}
