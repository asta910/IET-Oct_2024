import shapes.Operations;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

    //menu
        Scanner sc = new Scanner(System.in);
        System.out.println("1. Create Shape \n2. Get count \n3. Delete Shape \n4. Get Area by Index \n5. sort by area  \n6. Exit..");
        System.out.print("Select option : ");
        int choice = sc.nextInt();

        while(choice!=6){
            switch(choice){
                case 1:
                    boolean res = Operations.createShape();
                    if (res){
                        System.out.println("Shape inserted successfully..");
                    }else {
                        System.out.println("Operation failed..");
                    }
                    break;
                case 2:
                    Operations.getShapeCount();
                    break;
                case 3:
                    boolean res1 = Operations.deleteShape();
                    if (res1){
                        System.out.println("Shape deleted successfully..");
                    }else {
                        System.out.println("Operation failed..");
                    }
                    break;
                case 4:
                    Operations.getAreaIndex();
                    break;
                case 5:
                    Operations.sortByArea();
                    break;
                default:
                    System.out.println("Only 5 options availbale. ");
                    break;
            }
            System.out.println("1. Create Shape \n2. Get count \n3. Delete Shape \n4. Get Area by Index  \n5. sort by area  \n6. Exit..");
            System.out.print("Select option : ");
            choice = sc.nextInt();
        }

        System.out.println("Thank you..");
        sc.close();
    }
}