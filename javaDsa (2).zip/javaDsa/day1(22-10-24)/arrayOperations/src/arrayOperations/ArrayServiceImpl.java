package arrayOperations;

import java.util.*;

public class ArrayServiceImpl implements ArrayService{

//1
    public int findLargest(int[] a) {
        if(a.length==0) return -1;
        int max = a[0];
        for(int i :a){
            if(i>max){
                max=i;
            }
        }
        return max;
    }

//2
    public int secondLargest(int[] a) {
        int max=a[0],sec=Integer.MIN_VALUE;
        for(int i=1;i<a.length;i++){
            if(a[i] >= max){
                sec=max;
                max=a[i];
            }
            if(a[i] > sec && max > a[i]){
                sec=a[i];
            }
        }
        return sec;
    }

    //3
    public int nThLargest(int[] a, int k) {
        for (int i =0; i < k; i++){

            for (int j = 0; j < a.length - 1 - i; j++){

                if(a[j]>a[j+1]){
                    int temp = a[j];
                    a[j]=a[j+1];
                    a[j+1]=temp;
                }
            }
        }
        return a[a.length - k];
    }

//4
    public int primeSum(int[] a) {
        int sum=0;
        for (int i = 0; i < a.length; i++) {
            boolean result = true;

            if (a[i] == 0 || a[i] == 1 || a[i] == 2){
                if (a[i] == 0 || a[i] == 1) result = false;
                if (a[i] == 2) result = true;
            }else{
                for (int j = 2; j < i; j++) {
                    if (a[i] % j == 0){
                        result = false;
                        break;
                    }
                }
            }
            if (result) {
                sum += a[i];
            }
        }
        return sum;
    }

//5
    public int smallest(int[] a) {
        int min=a[0];
        for (int i = 0; i < a.length; i++) {
            if(min>a[i]){
                min=a[i];
            }
        }
        return min;
    }

    //6
    public int sumOfPerfectSquares(int[] a) {
        int sum = 0;
        for (int i : a){
            double sqr = Math.sqrt(i);

            if(sqr == Math.floor(sqr)){
                System.out.println(sqr + " " + Math.floor(sqr) + " accepted ");
               sum += i;
            }
        }
        return sum;
    }

//7
    public int subarraySum(int[] a) {
        int sum=0;
        for(int i=0; i < a.length;i++){
            for (int j = i; j < a.length;j++){
                int subSum = 0;
                for (int k = i; k <= j; k++){
                    subSum += a[k];
                }
                sum+= subSum;
            }
        }
        return sum;
    }
//8
    public int maxSubarraySum(int[] a) {
        int maxSum=0;
        for(int i=0; i < a.length;i++){
            for (int j = i; j < a.length;j++){
                int subSum = 0;
                for (int k = i; k <= j; k++){
                    subSum += a[k];
                }
                maxSum = Math.max(subSum,maxSum);
            }
        }
        return maxSum;
    }
//9
    public int minSubarraySum(int[] a) {
        int maxSum=0;
        for(int i=0; i < a.length;i++){
            for (int j = i; j < a.length;j++){
                int subSum = 0;
                for (int k = i; k <= j; k++){
                    subSum += a[k];
                }
                maxSum = Math.min(subSum,maxSum);
            }
        }
        return maxSum;
    }
//10
    public int findMissingFromNNUmbers(int[] a) {
        int n = a.length + 1;
        int nSum = n * (n+1)/2;
        int sum = 0;
        for (int i : a) sum+=i;
        return nSum - sum;
    }
//11
    public int[] merger(int[] a, int[] b) {
        int[] ans = new int[a.length + b.length];
        int i = 0; int j = 0; int k = 0;
        while (i < a.length && j < b.length){
            if (a[i] > b[j]){
                ans[k]=b[j];
                k++;
                j++;
            }else{
                ans[k++]=a[i++];
            }
        }
        while (i < a.length){
            ans[k++]=a[i++];
        }
        while (j < b.length){
            ans[k++]=b[j++];
        }
        return ans;
    }

//12
    public int[] rotate(int[] a) {
        int i =0;int j = a.length -1;
        while ( i < j){
            int temp = a[i];
            a[i]=a[j];
            a[j]=temp;
            i++;
            j--;
        }
        return a;
    }
//13
    public int[] findDoubles(int[] a) {
        Map<Integer,Integer> map = new HashMap<>();
        for (int i : a) map.put(i,map.getOrDefault(i,0)+1);
        List<Integer> ans = new ArrayList<>();
        for (Map.Entry<Integer,Integer> e : map.entrySet()){
            if (e.getValue() >= 2){
                ans.add(e.getKey());
            }
        }
        return ans.stream().mapToInt(i -> i).toArray();
    }

//14
    public int[] twoSum(int[] a,int target) {
        Map<Integer,Integer> map = new HashMap<>();

        for(int i=0; i < a.length; i++){
            int compliment = target - a[i];
            if (map.containsKey(compliment)){
                return new int[] {map.get(compliment),i};
            }
            map.put(a[i],i);
        }
        return new int[]{-1,-1};
    }

//15
    public int[] threeSun(int[] a,int target) {
        int start =0; int end = a.length -1;
        while(start < end && start != end){

            while (start-2<end){
                for (int i = start + 1; i < end -1; i++){

                    int sum = a[start] + a[i] + a[end];
                    if (sum == target){
                        return  new int[]{start,i,end};
                    }
                }
                start++;
            }

            while (start - 2 < end){
                for (int i = start + 1; i < end -1; i++){
                    int sum = a[start] + a[i] + a[end];
                    if (sum == target){
                        return  new int[]{start,i,end};
                    }
                }
                end--;
            }
        }
        return new int[]{-1,-1,-1};
    }
//16
    public int[] productArray(int[] a) {
        int[] ans = new int[a.length];
        for (int i =0; i < a.length; i++){
            int product = 1;
            for (int j =0; j < a.length; j++){
                if (i == j) continue;
                product *= a[j];
            }
            ans[i]=product;
        }
        return ans;
    }
//17
    public int missingPositive(int[] a) {
        int n = a.length + 1;
        int totalSum = n * (n+1)/2;
        int sum = 0;
        for(int i : a) sum+=i;

        return totalSum - sum;
    }
//18
    public int findCountOf(int[] a, int target) {
        int count = 0;
        for (int i : a){
            if (i == target) count++;
        }
        return count;
    }
//19
    public int peakElement(int[] a) {
        for (int i = 1; i < a.length -1 ; i++){
            if (a[i-1] < a[i] && a[i] > a[i+1]){
                return i;
            }
        }
        return -1;
    }
//20
    public int valleyElement(int[] a) {
        for (int i = 1; i < a.length -1 ; i++){
            if (a[i-1] > a[i] && a[i] < a[i+1]){
                return i;
            }
        }
        return -1;
    }
//21
    public int[] subarrayWithGivenSum(int[] a,int target) {
        for (int i =0; i < a.length; i++){
            for (int j = 0; j < a.length; j++){
                int subSum = 0;
                for (int k = i; k <= j; k++) {
                    subSum += a[k];
                }
                if (subSum == target){
                    return new int[]{i,j};
                }
            }
        }
        return new int[]{-1,-1};
    }
//22
    public boolean isSubset(int[] main, int[] sub) {
        if (sub.length > main.length) return false;
        int start = sub[0];
        int maxCountOfSame = 0;
        for (int i =0; i < sub.length; i++){
            if (main[i] == start){
                int count = 0;
                for (int j = 0; j < sub.length; j++){
                    if (main[i+j] == sub[j]){
                        count++;
                    }
                }
                maxCountOfSame = Math.max(count,maxCountOfSame);
            }
        }
        return maxCountOfSame == sub.length;
    }
//23
    public int[] unionAndIntersection(int[] a,int[] b) {
        Set<Integer> set = new HashSet<>();
        for (int i : a) set.add(i);
        for (int i : b) set.add(i);
        int[] ans = new int[set.size()];
        int count = 0;
        for (int i : set){
            ans[count++] = i;
        }
        return ans;
    }
//24
    public int countPairsWithSum(int[] a, int target) {
        Map<Integer,Integer> map = new HashMap<>();
        int count = 0;
        for(int i=0; i < a.length; i++){
            int compliment = target - a[i];
            if (map.containsKey(compliment)){
                count++;
            }
            map.put(a[i],i);
        }
        return count;
    }
//25
    public int[] commonCountInThreeArrays(int[] a, int[] b, int[] c) {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>();
        Set<Integer> set3 = new HashSet<>();
        Set<Integer> ans = new HashSet<>();
        for (int i : a) set1.add(i);
        for (int i : b) set2.add(i);
        for (int i : c) set3.add(i);
        for (int i : set1){
            if (set2.contains(i) && set3.contains(i)){
                ans.add(i);
            }
        }
        int an[] = new int[ans.size()];
        int count = 0;
        for (int i : ans){
            an[count++] = i;
        }
        return count== 0 ? null : an;
    }
//26
    public boolean subArrayWithZeroSum(int[] a) {
        for (int i =0; i < a.length; i++){
            for (int j = 0; j < a.length; j++){
                int subSum = 0;
                for (int k = i; k <= j; k++) {
                    subSum += a[k];
                }
                if (subSum == 0){
                    return true;
                }
            }
        }
        return false;
    }
//27
    public int[] findExtraNumbers(int[] a){
        int n = a.length - 2;
        int sn = n * (n+1)/2;
        int numFactorial = 1;
        int originalSum = 0;
        int originalProduct = 1;
        for (int i =0; i < a.length; i++){
            originalSum += a[i];
            originalProduct *= a[i];
            if (i == 0 || i + 1 >= a.length) continue;
            numFactorial *= i;
        }
        int sum = originalSum-sn;
        System.out.println("Product is : " + originalProduct/numFactorial+ ", sum is : " + sum );

        int n1 = sum/2;
        int n2=sum-n1;
        return findTwoNumbers2(sum,originalProduct/numFactorial,n1,n2);
    }
//28
    public  int[] findTwoNumbers2(int s,int p,int n1,int n2){
        if (n1==0 || n2 == 0) return new int[]{-1,-1};
        while (n1 != 0 && n2 != 0){
            if (n1*n2 == p && n1+n2 == s){
                return new int[] {n1,n2};
            }
            if (n1*n2 > p){
                return findTwoNumbers2(s,p,n1,n2-1);
            }if(n1*n2<p){
                return findTwoNumbers2(s,p,n1+1,n2);
            }
        }
        return new int[]{-1,-1};
    }

//29
    public int[] sortNRangedArray(int[] a){

        int max = Integer.MIN_VALUE;
        for (int i : a) max = Math.max(i,max);
        int[] count = new int[max+1];
        for (int i = 0; i < a.length; i++){
            count[a[i]]++;
        }

        int[] ans = new int[a.length];
        int index = 0;

        for (int i = 0; i < count.length ; i++) {
            int ct = count[i];
            while (ct>0){
                ans[index++]=i;
                ct--;
            }
        }
        return ans;
    }
}


