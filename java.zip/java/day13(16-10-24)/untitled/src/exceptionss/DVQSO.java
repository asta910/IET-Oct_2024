package exceptionss;

import java.util.Scanner;

public class DVQSO {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Enter two numbers: ");
            int num1 = sc.nextInt();
            int num2 = sc.nextInt();
            String s = null;
            if (s == null){
                throw new MyStringException("Cannot find length of string");
            }
            if (num2 == 0) {
                throw new MyNewException("Cannot divide by zero!");
            }

            System.out.println("Division is: " + (num1 / num2));
        }
        catch (MyStringException e ) {
            System.out.println(e.getMessage());
        }
        catch (MyNewException e ) {
            System.out.println(e.getMessage());
        }
        finally {
            System.out.println("Finally reached");
        }
    }
}
