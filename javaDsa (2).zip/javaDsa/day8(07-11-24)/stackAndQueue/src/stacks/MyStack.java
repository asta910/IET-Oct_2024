package stacks;

public class MyStack {
    private int top;
    private int[] arr;
    public MyStack(){
        top = -1;
        arr=new int[10];
    }
    public MyStack(int size){
        top = -1;
        arr=new int[size];
    }
    public boolean isEmpty(){
        return top == -1;
    }
    public boolean isFull(){
        return top + 1 == arr.length;
    }
    public int pop() throws StackOverflowError{
        int ans = Integer.MIN_VALUE;
        if (isEmpty()){
            System.out.println("Stack is empty");
        } else {
            try {
                if (isEmpty()){
                    throw new StackOverflowError();
                }
                ans = arr[top--];
            }catch (StackOverflowError e){
                System.out.println(e.getStackTrace());
            }
        }
        return ans;
    }

    public void push(int v){
        if (isFull()){
            System.out.println("Stack is full");
        }else{
            arr[++top]=v;
        }
    }
}
