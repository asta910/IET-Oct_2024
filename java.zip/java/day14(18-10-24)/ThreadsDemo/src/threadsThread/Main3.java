package threadsThread;

import beans.MyClass;
import runnableThreads.Provider3;

public class Main3 {
    public static void main(String[] args) {
        MyClass m1 = new MyClass();
        Provider3 p3 = new Provider3(m1, 76);
        Provider3 p4 = new Provider3(m1,48);

        Thread thread = new Thread(p3);
        Thread thread1 = new Thread(p4);

        thread1.setPriority(Thread.MIN_PRIORITY);
        thread.start();
        thread1.start();
        try {
            thread1.join();
            thread.join();
        }catch (InterruptedException e){
            System.out.println(e.getMessage());
        }


    }
}
