package demo.bean.dao;

import demo.bean.bean.Employee;

import javax.swing.plaf.InsetsUIResource;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeDaoImpl implements EmployeeDao {
    private List<Employee> list;

    public EmployeeDaoImpl() {
        list = new ArrayList<>();
//        list.add(new Employee(3, "Omen", 25000, 2000));
//        list.add(new Employee(4, "Ronaldo", 40000, 4000));
//        list.add(new Employee(2, "Asta", 50000, 4000));
//        list.add(new Employee(1, "Ancient One", 20000, 1000));
    }

    public void readDatFromFile(String fileName) {
        try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(fileName))) {
            while (true) {
                Employee employee = (Employee) objectInputStream.readObject();
                list.add(employee);
            }
        } catch (EOFException e) {
            System.out.println("Reached end of file. Total employees loaded: " + list.size());
        } catch (FileNotFoundException e) {
            System.out.println("File does not exist: " + fileName);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    public void modifyEmployee(Employee employee,char ch,int updated) {
        if (ch == 'b'){
            employee.setBonus(updated);
        }else if (ch == 's'){
            employee.setSal(updated);
        }else {
            System.out.println("Operation failed..");
        }
    }
    public Employee findEmployee(int id){
        int position = list.indexOf(new Employee(id));
        Employee ans = list.get(position);
        if (ans != null){
            return ans;
        }
        return null;
    }

    public List<Employee> sortBySalary() {
        List<Employee> ans = list.stream().sorted((obj1,obj2) -> Double.compare(obj1.getSal() , obj2.getSal()) ).collect(Collectors.toUnmodifiableList());
        return ans;
    }


    public List<Employee> sortByID() {
        List<Employee> ans = list.stream().sorted((obj1,obj2)->Integer.compare(obj1.getEmpid(), obj2.getEmpid())).collect(Collectors.toUnmodifiableList());
        return ans;
    }

    public void saveEmployeeToList(Employee employee) {
        list.add(employee);
    }

    public List<Employee> showAll() {
        return new ArrayList<>(list);
    }

    public void remove(Employee employee) {
        list.remove(employee);
    }

    public void removeEmployee(Employee employee) {
        list.remove(employee);
    }

    public void saveToFile(String fileName) {
        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(fileName))) {
            for (Employee employee : list) {
                objectOutputStream.writeObject(employee);
            }
            System.out.println("Employees saved successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveInFile(String path){
        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(path))){
            for (Employee e : list){
                objectOutputStream.writeObject(e);
            }
        }catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
}