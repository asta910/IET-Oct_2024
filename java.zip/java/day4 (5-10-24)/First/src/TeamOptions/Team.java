package TeamOptions;

import java.util.ArrayList;
import java.util.Arrays;

public class Team {
        private int tid;
        private String teamName;
        private String coachName;
        private Player captain;
        private static final int MAX_PLAYERS = 20;
        private Player[] players = new Player[MAX_PLAYERS];
        private int playerCount = 0;
        public static Team[] teams = new Team[10];
        static int count = 0;

        @Override
        public String toString() {
                Player[] available = availablePlayers(players);
                return "Team{" +
                        "tid=" + tid +
                        ", teamName='" + teamName + '\'' +
                        ", coachName='" + coachName + '\'' +
                        ", captain=" + captain +
                        ", players=" + Arrays.toString(available) +
                        '}';
        }

        public Player[] availablePlayers(Player[] players) {
                int count = 0;
                for (Player p : players) {
                        if (p != null) count++;
                        else break;
                }

                return Arrays.copyOf(players, count);
        }

        public Team(int tid, String teamName, String coachName, Player captain) {
                this.tid = tid;
                this.teamName = teamName;
                this.coachName = coachName;
                this.captain = captain;
        }

        public boolean addPlayer(Player p) {
                if (playerCount < MAX_PLAYERS) {
                        players[playerCount++] = p;
                        return true;
                }
                return false; // Not added if array is full
        }

        public static Team[] showAllTeams() {
                return Arrays.copyOf(teams, count);
        }

        public static void addTeam(Team team) {
                if (count < teams.length) {
                        teams[count++] = team;
                } else {
                        System.out.println("Maximum number of teams reached.");
                }
        }
}
