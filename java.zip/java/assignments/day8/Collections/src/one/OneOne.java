package one;
//Accept 3 numbers from command line arguments. If number is prime, then print the table of
//the number. Other wise divide number by 10 and display output
public class OneOne {
    public static void main(String[] args) {

        for (int i = 0; i < args.length; i++) {
            String string = args[i];
            int s = Integer.parseInt(string);

            if(isPrime(s)){
                for(int j=1;j<11;j++){
                    System.out.println(s + " * "+j+" = "+s*j);
                }
            }else{
                System.out.println("Number is not prime so divided by 10 : " + s/10);
            }
        }

    }
    static boolean isPrime(int s) {
        if (s == 0) return false;
        if (s == 1) return false;
        if (s == 2) return true;
        for (int i = 2; i < s; i++) {
            if(s%i==0){
                return false;
            }
        }
        return true;
    }

}
