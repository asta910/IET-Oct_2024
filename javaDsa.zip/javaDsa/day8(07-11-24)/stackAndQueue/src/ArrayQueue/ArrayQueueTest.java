package ArrayQueue;

public class ArrayQueueTest {
    public static void main(String[] args) {
        Circular queuearr = new Circular(5);
        queuearr.enqueue(10);
        queuearr.enqueue(4);
        queuearr.enqueue(6);
        queuearr.enqueue(90);
        queuearr.enqueue(6);
        queuearr.enqueue(2);
        queuearr.enqueue(27);
        System.out.println(queuearr);
        System.out.println(queuearr.dequeue());
        System.out.println(queuearr.dequeue());
        System.out.println(queuearr.dequeue());
        System.out.println(queuearr.dequeue());
        System.out.println(queuearr.dequeue());
        System.out.println(queuearr.dequeue());

    }

}
