package quick;

import java.util.Arrays;

public class QuickSortyyy {
    public static void main(String[] args) {
        int[] array = {70,40,50,90,100,10,30,20,10,30,100,50,20,10,70,40,50,90,100};
        System.out.println(Arrays.toString(array));
        quick(array,0, array.length-1);
        System.out.println(Arrays.toString(array));
    }
    static void quick(int[] a,int start,int end){
        if (start >= end) return;
        int left = start;
        int right = end;
        int mid = (left+right)/2;
        int pivot = a[mid];

        while (left < right){
            while (pivot > a[left]){
                left++;
            }
            while (pivot < a[right]){
                right--;
            }
            if (left <= right){
                int temp = a[left];
                a[left] = a[right];
                a[right]=temp;
                left++;
                right--;
            }
        }
        quick(a,start,right);
        quick(a,left,end);
    }

}
