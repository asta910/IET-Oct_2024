package linkedList;

public class TestLinkedList {
    public static void main(String[] args) {
        MyLinkedList list = new MyLinkedList();

        for (int i =1; i <= 10; i++){
            list.add(i*10);
        }

        list.display();
        System.out.println();
        list.reverseHalf();
        list.display();

    }
}
