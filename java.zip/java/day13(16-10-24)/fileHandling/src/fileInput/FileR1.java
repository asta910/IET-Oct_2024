package fileInput;

import javax.xml.crypto.Data;
import java.io.*;

public class FileR1 {
    public static void main(String[] args) throws IOException{
        try (DataInputStream dataReader = new DataInputStream(new FileInputStream("one1.txt"));
             DataOutputStream dataWriter = new DataOutputStream(new FileOutputStream("two1.txt"));
        ){
            int number  = dataReader.read();
            String s = dataReader.readUTF();
            char c = dataReader.readChar();

            while (number != -1){
                dataWriter.writeChar(c);
                dataWriter.write(number);
                dataWriter.writeUTF(s);
                number  = dataReader.read();
                s = dataReader.readUTF();
                c = dataReader.readChar();
                System.out.println(s.getBytes() + " " + c + " " + number);
            }

        }catch (IOException e ){
            System.out.println(e.getMessage());
        }
    }
}
