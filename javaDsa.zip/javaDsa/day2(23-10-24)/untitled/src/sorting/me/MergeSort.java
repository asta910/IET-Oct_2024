package sorting.me;

import java.util.Arrays;

public class MergeSort{
    public static void main(String[] args) {
        int[] array = {70,40,50,90,100,10,30,20,10,30};
        System.out.println(Arrays.toString(array));
        int[] ans = sort(array);
        System.out.println(Arrays.toString(ans));
    }

    public static int[] sort(int[] a){
        if (a.length == 1) return a;
        int mid = a.length/2;
        int[] left = Arrays.copyOfRange(a,0,mid);
        int[] right = Arrays.copyOfRange(a,mid,a.length);

        left = sort(left);
        right = sort(right);

        return merger(left,right);
    }

    public static int[] merger(int[] a, int[] b) {
        int[] ans = new int[a.length + b.length];
        int i = 0; int j = 0; int k = 0;
        while (i < a.length && j < b.length){
            if (a[i] > b[j]){
                ans[k]=b[j];
                k++;
                j++;
            }else{
                ans[k++]=a[i++];
            }
        }
        while (i < a.length){
            ans[k++]=a[i++];
        }
        while (j < b.length){
            ans[k++]=b[j++];
        }
        return ans;
    }
}
