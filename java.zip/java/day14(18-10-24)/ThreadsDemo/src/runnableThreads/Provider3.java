package runnableThreads;

import beans.MyClass;

public class Provider3 implements Runnable{
    private MyClass object;
    private int n;

    public Provider3(MyClass object,int n){
        this.object = object;
        this.n  = n;
    }

    public void run() {
       object.primeNum(n);
    }


}
