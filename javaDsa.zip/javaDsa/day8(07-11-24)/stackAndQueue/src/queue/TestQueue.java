package queue;

public class TestQueue {
    public static void main(String[] args) {
        MyQueue<Integer> queue = new MyQueue<>();
        queue.offer(10);
        queue.offer(20);
        queue.offer(30);
        queue.offer(40);
        queue.offer(50);
        queue.offer(60);
        for (int i =0; i < 10; i++){
            System.out.println(queue.remove());
        }
//        System.out.println(queue);
    }
}
