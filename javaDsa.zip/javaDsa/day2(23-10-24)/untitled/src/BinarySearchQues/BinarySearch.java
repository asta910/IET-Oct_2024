package BinarySearchQues;

public interface BinarySearch {
    int[] searchLowerAndUpperBound(int[] a);
    int searchLowerInsertPPosition(int[] a);
    int[] firstAndLastOccurance(int[] a);
    int searchInSortedRotatedArray(int[] a);
    int minElementInRotatedArray(int[] a);
    int peakElementInMountedArray(int[] a);
}
