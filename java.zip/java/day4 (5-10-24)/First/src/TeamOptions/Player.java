package TeamOptions;

public class Player {
    private static int count;
    private int playerid;
    private String playername;
    private String speciality;
    private int age;

    Player(int pid,String pname,String special,int age)
    {
        this.playerid = pid;
        this.playername = pname;
        this.speciality = special;
        this.age = age;
        count++;
    }
    Player(){}

    @Override
    public String toString() {
        return "Player{" +
                "playerid=" + playerid +
                ", playername='" + playername + '\'' +
                ", speciality='" + speciality + '\'' +
                ", age=" + age +
                '}';
    }

    public static int getTotalPlayers(){
        return count;
    }

    public int getPlayerid() {
        return playerid;
    }

    public void setPlayerid(int playerid) {
        this.playerid = playerid;
    }

    public String getPlayername() {
        return playername;
    }

    public void setPlayername(String playername) {
        this.playername = playername;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
