drop PROCEDURE if exists PROC;
delimiter $
create PROCEDURE PROC(in _table varchar(20),in _deptno int);
BEGIN


END $
delimiter ;