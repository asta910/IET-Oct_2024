package fileReader;

import java.io.FileReader;
import java.io.FileWriter;

public class FR {
    public static void main(String[] args) throws Exception{
        try(FileReader frs = new FileReader("test1");
            FileWriter fos = new FileWriter("testReaderCopy");){

            int f;
            while ((f = frs.read()) != -1) {
                fos.append((char) f);
            }
        }
        catch (Exception e){

        }
    }
}
