package com.demo.services;

public interface LoginService {
    int whoIsThis(String n,String p);
}
