package com.demo.service;


public class ServiceImpl implements Service {

    public void addEmployee() {

    }

    public void sortEmployee() {

    }
}
