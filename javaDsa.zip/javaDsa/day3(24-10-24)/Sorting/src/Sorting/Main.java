package Sorting;
public class Main {
    public static void main(String[] args) {
        int[] array = {0, 1, 2, 4, 5};
        int result = missingNumber(array);
        System.out.println("The missing number is: " + result);
    }

    private static int missingNumber(int[] a) {
        int n = a.length; // Length of the array
        int missing = n;  // Start with n as the initial missing value

        // XOR all elements in the array
        for (int i = 0; i < n; i++) {
            missing ^= a[i]; // XOR with each element
        }

        // XOR with all numbers from 0 to n
        for (int i = 0; i < n; i++) {
            missing ^= i; // XOR with each index
        }

        return missing; // Return the missing number
    }
}