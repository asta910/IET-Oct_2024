package three.second;

import three.first.Student2;

import java.util.List;

public class FriendService {
    FriendsDao dao = new FriendsDao();

    public void displayAll(){
        List<Friends> s = dao.showAll();
        for(Friends friends:s){
            System.out.println(friends);
        }
    }

    public void searchById(int id) {

    }

    public void searchByName(String name) {
    }

    public void displayByHobbie() {
    }
}
