package Sorting;

import java.util.Arrays;

public class InsertionSort {
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,8,0,4,8,2,7};
        insertionSort(arr);
        System.out.println(Arrays.toString(arr));
    }

    private static void insertionSort(int[] arr) {
        for (int i = 0; i < arr.length ; i++) {
            int j =i-1;
            int num=arr[i];
            while(j>=0 && arr[j]>num){
                arr[j+1]=arr[j];
                j--;
            }
            arr[j+1]=num;

        }
    }
}

