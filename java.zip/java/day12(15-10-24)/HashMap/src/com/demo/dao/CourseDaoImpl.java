package com.demo.dao;
import com.demo.bean.Course;

import java.util.*;

public class CourseDaoImpl implements CourseDao{
    static Map<String, Course> map;
    static {
        map= new HashMap<>();
        map.put("CS",new Course("CS",60000.23,75,260,new String[] {"Yogita","daku"},new String[] {"M1","CS","M2","M3","SNS","AI","ML"}));
        map.put("MAC",new Course("MAC",40000.23,50,230,new String[] {"James","Soily"},new String[] {"M1","CAR","M2","M3","BIKE","Robo","MECH-T"}));
        map.put("IT",new Course("IT",50000.00,60,210,new String[] {"Omen","someone","everyone"},new String[] {"OS","ML","DL","TOC","IOT","M1","M2","M3","PA"} ));
        map.put("ENTC",new Course("ENTC",50000.00,60,190,new String[] {"Rock","Asta","Naruto"},new String[] {"Electronics","Modeling","Circuits","Embedded","IOT","M1","M2","M3","HardWare"} ));
    }

    public boolean addCourse(String cname,Course c){
        map.put(cname,c);
        return true;
    }

    public Course findByName(String s){
        return map.get(s);
    }


    public Map<String, Course> findByDur(int duration) {
        Map<String,Course> ans = new HashMap<>();
        for(Map.Entry<String,Course> e: map.entrySet()){
            if(e.getValue().getDuration() > duration){
                ans.put(e.getKey(),e.getValue());
            }
        }
        return ans.size() == 0 ? null : ans;
    }


    public Map<String, Course> displayAll() {
        return map;
    }
    public Course findCourse(String s){
        Course cours = map.get(s);
        return cours;
    }

    public void deleteCourse(String nm,Course course) {
        map.remove(nm,course);
    }
    //8. Display in sorted order of name
    public Map<String,Course> nameSorted(){
        Map<String,Course> ans = new TreeMap<>();
        ans.putAll(map);
        return ans;
    }
    //dur sorted
    public Map<String,Course>  durationSorted(){
        List<Map.Entry<String, Course>> entryList = new ArrayList<>(map.entrySet());
        entryList.sort((a, b) -> Integer.compare(a.getValue().getDuration(), b.getValue().getDuration()));

        Map<String,Course> ans = new LinkedHashMap<>();
        for (Map.Entry<String,Course> e : entryList){
            ans.put(e.getKey(),e.getValue());
        }
        return ans.size() == 0 ? null : ans;
    }

    public Map<String, Course> feesSorted() {
        List<Map.Entry<String,Course>> list = new ArrayList<>(map.entrySet());
        list.sort((a,b) -> Double.compare(a.getValue().getFees(),b.getValue().getFees()));

        Map<String,Course> ans = new LinkedHashMap<>();
        for (Map.Entry<String ,Course> e : list){
            ans.put(e.getKey(),e.getValue());
        }
        return ans.size() == 0 ? null : ans;
    }

}
