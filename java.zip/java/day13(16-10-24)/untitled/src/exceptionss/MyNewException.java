package exceptionss;

public class MyNewException extends Exception {
    public MyNewException(String message) {
        super(message);
    }

}
