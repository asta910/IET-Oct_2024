package com.demo.services;

public interface ServiceInterface {
    boolean createStudent();
    boolean deleteStudent();
    boolean modifyMarks();

    void searchById();
    void displayByMarks();
    void sortById();
    void showAll();
    void sortByMarks();
    void sortByName();
    boolean addFaculty();
}
