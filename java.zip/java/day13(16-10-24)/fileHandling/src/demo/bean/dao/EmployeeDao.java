package demo.bean.dao;


import demo.bean.bean.Employee;

import java.util.List;

public interface EmployeeDao {
    void saveEmployeeToList(Employee employee);

    List<Employee> showAll();

    void remove(Employee employee);
    void readDatFromFile(String fileName);

    void modifyEmployee(Employee employee,char ch,int updated);
    Employee findEmployee(int id);

    List<Employee> sortBySalary();

    List<Employee> sortByID();
    void saveInFile(String path);
}
