import arrayOperations.ArrayService;
import arrayOperations.ArrayServiceImpl;
import reccursion.ReccursionService;
import reccursion.ReccursionServiceImpl;
import search.SearchService;
import search.SearchServiceImpl;

import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        ArrayService arrayService = new ArrayServiceImpl();
        ReccursionService reccursionService = new ReccursionServiceImpl();
        SearchService search = new SearchServiceImpl();


        int[] array = {70,40,50,90,100,10,30,20,10,30,100,50,20,10,70,40,50,90,100};
        int[] array2 = {1,2,6,8,5,6,3,4,9,16,14,13,12};
        int[] array22 = {1,2,6,9,145,145};
        int[] a = arrayService.sortNRangedArray(array2);
        System.out.println(Arrays.toString(a));


    }

}