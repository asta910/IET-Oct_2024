package sorting;

import java.util.Arrays;

public class Quicksort2 {
    public static void main(String[] args) {
        int[] array = {12, 35, 8, 9, 57, 32, 6, 8, 9, 84, 43, 75};
        quickSort(array,0, array.length-1);
        System.out.println(Arrays.toString(array));

    }
    public static void quickSort(int[] array,int start,int end){
        if (start >= end) return;
        int l = start;
        int r = end;
        int mid = (l+r)/2;
        int pivot = array[mid];

        while(l<r) {
            while (pivot > array[l]) {
                l++;
            }
            while (pivot < array[r]) {
                r--;
            }

            if(l <= r) {
                int temp = array[l];
                array[l] = array[r];
                array[r] = temp;
                l++;
                r--;
            }
        }
        quickSort(array,start,r);
        quickSort(array,l,end);
        }

    }

