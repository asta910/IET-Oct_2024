package avl;

import java.util.List;

public class TestAvl {
    public static void main(String[] args) {
         AVL tree = new AVL();
         for (int i= 1; i < 10; i++){
             tree.insert(i*10);
         }
         tree.showTree();

         List<Integer> ans = tree.inOrder();
         for(int i : ans){
             System.out.print(i + " ");
         }
        System.out.println("  <-- InOrder");

        List<Integer> ans1 = tree.preOrder();
        for(int i : ans1){
            System.out.print(i + " ");
        }
        
        System.out.println("  <-- PreOrder");

        List<Integer> ans2 = tree.postOrder();
        for(int i : ans2){
            System.out.print(i + " ");
        }
        System.out.println("  <-- PostOrder");
    }
}
