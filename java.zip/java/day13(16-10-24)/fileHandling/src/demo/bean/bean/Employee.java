package demo.bean.bean;

import java.io.Serializable;
import java.util.Objects;

public class Employee implements Serializable {
    private int empid;
    private String ename;
    private int sal;
    private int bonus;
    public Employee() {
        super();
    }
    public Employee(int id){
        this.empid=id;
    }
    public Employee(int empid, String ename, int sal, int bonus) {
        super();
        this.empid = empid;
        this.ename = ename;
        this.sal = sal;
        this.bonus = bonus;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return empid == employee.empid;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(empid);
    }

    @Override
    public String toString() {
        return
                "employee_id : " + empid +
                ", name : " + ename+
                ", sal : " + sal +
                ", bonus : " + bonus;
    }

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public double getSal() {
        return sal;
    }

    public void setSal(int sal) {
        this.sal = sal;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(int bonus) {
        this.bonus = bonus;
    }
}
