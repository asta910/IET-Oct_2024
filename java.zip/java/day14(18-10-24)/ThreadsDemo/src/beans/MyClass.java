package beans;

public class MyClass {

    synchronized public void printTable(int n){
        for (int i =1; i <= 10; i++){
            System.out.println(i + " * " + n + " = " + i*n );
        }
    }

    synchronized public void printFibo(int n){
        if (n == 0){
            System.out.println("1st factorial : " + 0);
            return;
        }
        if (n == 1){
            System.out.println("1 - factorial : 0");
            System.out.println("2 - factorial : 1");
            return;
        }
        int[] dp = new int[n+1];
        dp[0]=0;
        dp[1]=1;
        for (int i = 2; i <=n; i++){
            dp[i] = dp[i-1]+dp[i-2];
            int index = i + 1;
            System.out.println( index +  " - factorial : " + dp[i]);
        }
    }
    public void primeNum(int n){
        for(int i=0;i<=n;i++){
            if (isPrime(i)){
                System.out.println(n + " prime umber is : " + i);
            }
        }
    }
    private boolean isPrime(int n){
        if(n==0)return false;
        if(n==1)return false;
        if(n==2)return true;
            for (int i = 2; i < Math.sqrt(n); i++){
                if (n % i == 0) return false;
            }
            return true;
    }



}
