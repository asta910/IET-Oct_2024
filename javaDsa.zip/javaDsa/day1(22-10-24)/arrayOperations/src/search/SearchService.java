package search;

public interface SearchService {
    int linearSearch(int[] a,int target);
    int binarySearch(int[] a,int low,int high,int target);
}
