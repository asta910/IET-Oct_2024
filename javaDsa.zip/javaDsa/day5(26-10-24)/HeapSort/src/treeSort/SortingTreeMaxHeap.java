package treeSort;

public class SortingTreeMaxHeap {

    public static void heapSort(int[] a){
        int n = a.length;

        for (int i = (n/2) -1; i >= 0; i--){
            heapify(a,n,i);
        }

        for (int i = n-1; i > 0; i--){
            int temp = a[0];
            a[0] = a[i];
            a[i] = temp;
            heapify(a,i,0);
        }
    }


    public static void heapify(int[] a,int n,int index){
        int large = index;
        int left = index * 2 + 1;
        int right = index * 2 + 2;

        if (left < n && a[left] > a[large])     large = left;
        if (right < n && a[right] > a[large])   large = right;

        if (large != index){
            int temp = a[large];
            a[large] = a[index];
            a[index] = temp;
            heapify(a,n,large);
        }
    }
}
