package TeamOptions;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Player vk = new Player(18, "Virat", "Batsman", 34);
        Player ab = new Player(17, "A B Devilliers", "Batsman", 36);
        Team RCB = new Team(1, "RCB", "Rahul Dravid", vk);
        RCB.addPlayer(vk);
        RCB.addPlayer(ab);

        Player ms = new Player(7, "Dhoni", "Batsman", 39);
        Player jd = new Player(9, "Ravindra", "All-Rounder", 31);
        Team CSK = new Team(2, "CSK", "Fleming", ms); // Changed ID to 2
        CSK.addPlayer(ms);
        CSK.addPlayer(jd);

        Team.teams[0] = RCB;
        Team.teams[1] = CSK;

        while (true) {
            System.out.println("1. Show Teams \n2. Delete Team \n3. Search by ID \n10. Exit");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    Team[] ans = Team.showAllTeams();
                    if (ans.length != 0) {
                        for (Team t : ans) {
                            System.out.println(t);
                        }
                    } else {
                        System.out.println("No teams listed!");
                    }
                    break;

                case 10:
                    System.out.println("Exiting...");
                    sc.close();
                    return; // Exit the program

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

}
