package sorting.me;
import java.util.Arrays;

public class Quicksort {
    public static void main(String[] args) {
        int[] array = {70,40,50,90,100,10,30,20,10,30,100,50,20,10,70,40,50,90,100};
        System.out.println(Arrays.toString(array));
        quick(array,0, array.length-1);
        System.out.println(Arrays.toString(array));
    }
    private static void quick(int[] a,int start,int end){
        if (start >= end) return;
        int left = start;
        int right = end;
        int pivot = a[(left + right)/2];

        while (left < right){
            while (a[left] < pivot ){
                left++;
            }while (a[right] > pivot){
                right--;
            }
            if (left<=right){
                int temp = a[left];
                a[left++]=a[right];
                a[right--]=temp;
            }
        }
        quick(a,start,right);
        quick(a,left,end);
    }
}
