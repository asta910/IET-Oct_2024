package exceptionss;

public class MyStringException extends RuntimeException{
    public MyStringException(String s){
        super(s);
    }
}
