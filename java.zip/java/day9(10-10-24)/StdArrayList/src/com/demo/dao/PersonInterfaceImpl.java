package com.demo.dao;

import com.demo.beans.*;

import java.util.*;

public class PersonInterfaceImpl implements PersonInterface{
    static List<Person> personArray;
    Scanner sc = new Scanner(System.in);

    static{
        personArray = new ArrayList<>();
        personArray.add(new Graduation(2,"Omen","LA Galaxy",new int[]{80,90,90},99));
        personArray.add(new Masters(3,"Rock","Jamaica",new int[]{81,59,70},"WWE",84));

        personArray.add(new Graduation(4,"Devid Beckham","Manchester",new int[]{91,81,91},78));
        personArray.add(new Masters(1,"Krishna Ronaldo","Madira",new int[]{99,99,40},"Football",99));
    }



    public boolean createGraduationStudent(int gid,String gName,String gAddress,int[] m,int gssub){
        personArray.add(new Graduation(gid,gName,gAddress,m,gssub));
        return true;
    }

    public boolean createMastersStudent(int gid,String gName,String gAddress,int[] m,String mtsub,int gssub) {
        personArray.add(new Masters(gid,gName,gAddress,m,mtsub,gssub));
        return true;
    }

    //2 delete student
    public boolean deleteStudent(int id){
        Person newPerson = new Person(id);

        int position = personArray.indexOf(newPerson);

        if (position != -1){
            personArray.remove(position);
            return true;
        }
        return false;
    }


    //3 modify marks
    public boolean modifyMarks(int gid,int[] m){

        for(int i =0; i < personArray.size(); i++){
            if(personArray.get(i).getId() == gid){
                ((Student) personArray.get(i)).setMarks(m);
            }
            return true;
        }
        return false;
    }


    //4 search by id
    public void searchById(int gid){

        Person newPerson = new Person(gid);
        int position = personArray.indexOf(newPerson);

        if (position != -1){
            System.out.println(personArray.get(position));
        }
    }

    //11. add Faculty
    public boolean addFaculty(){
        System.out.print("Enter id : ");
        int gid = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter student name : ");
        String gName = sc.nextLine();
        System.out.println("Enter address : ");
        String gAddress = sc.nextLine();

        System.out.println("Enter special subject : ");
        String gspecialSubject = sc.nextLine();

        System.out.print("How many skills you want to add : ");
        int skillNo = sc.nextInt();

        String[] skills = new String[skillNo];
        for(int i =0; i < skillNo; i++){
            System.out.print("Enter skill number : " + i+1 );
            skills[i] = sc.nextLine();
        }

        System.out.println("Enter salary : ");
        int sal = sc.nextInt();

        Faculty newFaculty = new Faculty(gid,gName,gAddress,gspecialSubject,skills,sal);
        personArray.add(newFaculty);
        return true;
    }

    //5 display marks
    public ArrayList<Person> displayByMarks(){
        System.out.println("how many students got marks above, .... out of 100 ? ");
        int minMarks = sc.nextInt();

        ArrayList<Person> ans = new ArrayList<>();
        for (Person p : personArray){
            int marks = 0;
            if (p instanceof Graduation){
                marks = ((Graduation) p).getSpecialSubMarks();
            }else{
                marks = ((Masters) p).getThesisMarks();
            }

            if(marks > minMarks) ans.add(p);
        }
        return ans;
    }

    //6 sort by id
    public void sortById(){
        Collections.sort(personArray);
        showAll();
    }


    //7. Sort by name
    public void sortByName(){
        personArray.sort(new NameSort());
        showAll();
    }

    //8 sort by marks
    public void sortByMarks() {

        personArray.sort(new MarksSort());


        System.out.println("In which order\n1. Ascending \n2. Descending ");
        System.out.print("Enter your choice : ");
        int choice = sc.nextInt();
        if(choice == 1){
            System.out.println("Marks in Ascending order : ");
        }else{
            System.out.println("Marks in Descending order : ");
            Collections.reverse(personArray);
        }
        showAll();
    }

    //10. showAll
    public void showAll(){
        for (Person p : personArray){
            System.out.println(p);
        }
    }
}
