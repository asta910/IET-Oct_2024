package producerConsumer;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        Product product = new Product();
        AddProducts addProducts = new AddProducts(product);
        GetProducts getProducts = new GetProducts(product);
        addProducts.start();
        getProducts.start();

        try {
            addProducts.join();
            addProducts.join();
        }catch (InterruptedException e){
            System.out.println(e.getMessage());
        }

        List<Integer> ans = getProducts.getAns();
        for (int a : ans){
            System.out.println("Ans is : " + a);
        }
    }
}
