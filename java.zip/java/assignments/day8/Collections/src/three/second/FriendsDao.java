package three.second;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FriendsDao {
    static List<Friends> list;
    static {
        list= new ArrayList<>();
        list.add(new Friends( 1,"Asta","Kumar",new String[] {"painting","Killing"},12312312,"asta@gmail.com",new Date(2002-12-06),"Kadla"));
        list.add(new Friends( 2,"Naruto","Mishra",new String[] {"Cricket","Football"},231459012,"Mishra@gmail.com",new Date(2002-04-01),"jaun gela "));
        list.add(new Friends( 3,"Rengoku","Kiyojiro",new String[] {"Novel","Anime"},67766776,"Sharma@gmail.com",new Date(2002-07-03),"Kadi"));
    }

    public List<Friends> showAll(){
        return list;
    }




}
