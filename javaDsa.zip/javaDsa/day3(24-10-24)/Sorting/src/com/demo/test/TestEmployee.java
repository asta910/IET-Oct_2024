package com.demo.test;

import com.demo.service.Service;
import com.demo.service.ServiceImpl;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class TestEmployee {
    public static void main(String[] args) {
        Service service = new ServiceImpl();
//        int[] arr = new arr[3,"ttgy",]
//        int[] sortedArray = {};

        System.out.println("1. Add Employee \n 2.Sort \n 3. Exit");
        int choice = 0;
        Scanner sc = new Scanner(System.in);
        choice = sc.nextInt();
        while(choice!=3){
            switch(choice){
                case 1:
                    service.addEmployee();
//                    System.out.println(Arrays.toString(sortedArray));
                    break;
                case 2:
                    service.sortEmployee();
                    break;
                case 3:
                    sc.close();
                    System.out.println("Thank you for performing operations");
                    break;
                default:
                    System.out.println("You entered invalid choice");
                    break;
            }

        }
    }
}
