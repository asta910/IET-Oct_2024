package demo.bean.services;

public interface EmployeeService {
    void addEmployee();

    void DeleteEmployee(int id);

    void updateEmployee(int id);

    void displayEmployee();
    void readDatFromFile(String fileName);

    void sortBySalary();

    void sortByID();
    void saveInFile(String path);
}
