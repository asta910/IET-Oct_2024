import binaryTree.BinaryTree;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        BinaryTree binaryTree = new BinaryTree();
        for (int i =1; i < 10; i++){
            binaryTree.addNode(i);
        }

        List<Integer> ans =  binaryTree.bfs();
        for (int i : ans){
            System.out.print(i + "  ");
        }
        System.out.println("  BFS ");

        List<Integer> pre =  binaryTree.preOrder();
        for (int i : pre){
            System.out.print(i + "  ");
        }
        System.out.println("  PreOrder ");

        List<Integer> in =  binaryTree.inOrder();
        for (int i : in){
            System.out.print(i + "  ");
        }
        System.out.println("  InOrder");

        List<Integer> post =  binaryTree.postOrder();
        for (int i : post){
            System.out.print(i + "  ");
        }
        System.out.println("  PostOrder");


    }
}