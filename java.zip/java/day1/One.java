import java.util.Scanner;

class One{
	public static void main(String[] args){
	Scanner sc = new Scanner(System.in);
	int mul = 1;
	for(int i=1;i<3;i++){
	System.out.println("Enter numbers you want to multiply: ");
		int n = sc.nextInt();
		mul = mul*n;
		}		
	System.out.println("Multiplication is: "+mul);
	sc.close();
	}

}